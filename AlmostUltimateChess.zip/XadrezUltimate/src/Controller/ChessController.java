/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import View.BoardFrame;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Observer;
import Model.Chess;
import Pieces.King;
import Pieces.Pawn;
import Pieces.Pieces;
import Pieces.Queen;
import static java.awt.BasicStroke.CAP_BUTT;
import static java.awt.BasicStroke.CAP_ROUND;
import static java.awt.BasicStroke.JOIN_BEVEL;
import static java.awt.BasicStroke.JOIN_MITER;
import static java.awt.BasicStroke.JOIN_ROUND;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import static java.lang.Thread.sleep;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 *
 * @author Lenovo
 */
public class ChessController implements MouseListener, MouseMotionListener, ActionListener, KeyListener{
    
    private static JTextArea editTextArea = new JTextArea("");
    private BoardFrame view;
    private Chess model;
    private boolean testMove = false, gameover = false;
    private Point tA, tW, tB;
    private timer TimerA, TimerW, TimerB;
    private autosave Asave;
    private long savetime;
    private Pieces.Color Player1;
    private int gametype;
    /*----------------------------------Starting controll--------------------------------*/   
    public void addView(Observer view){
        this.view = (BoardFrame)view;
    }
    
    public void addModel(Chess model){
        this.model = model;
        this.setPlayer1(Pieces.Color.WHITE);
        gametype = 30;
        tA = new Point(0,0);
        tW = new Point(0,gametype);
        tB = new Point(0,gametype);
        savetime = 31;
        
        
        
        
        

        TimerA = new timer(this, 0, tA);
        TimerA.start();
        TimerW = new timer(this, 1, tW);
        TimerW.start();
        TimerB = new timer(this, 2, tB);
        TimerB.start();
        
        Asave = new autosave (this, savetime);
        Asave.start();
      
        
    }
    /*-----------------------------------Draw--------------------------------------*/    
     public void drawPlayerLabel(){
        view.setPlayerLabel(model.getPlayer(), model.getChecked(), model.getCheckMate());
    }

    public void drawHighlighted(Graphics2D g){
        if(model.getSelectedPiece() != null){
            if (this.testMove){ //if it's necessary check the tiles to paint
                model.cleanOverTiles(); //clean the tiles vector
                model.cleanOverTilesEnemy();
                int i, j;
                for(i=0; i<8; i++){ //check all moves possibles
                    for(j=0; j<8; j++){  //check if the king will be in check
                        if( model.getChecked() && !model.canBlockTile(model.getSelectedPiece().getColor(), model.getSelectedPiece(), i, j) &&
                            model.getChecked() && !model.canEatTile(model.getSelectedPiece().getColor(), model.getSelectedPiece(), i, j) &&
                            model.getChecked() &&  model.getSelectedPiece().getClass() != King.class){
                        }
                        else{   //if the move will not let king dies
                            if(i != model.getMouseCoord().x/50 || j != model.getMouseCoord().y/50){ //if mouse isnt over the tile
                                if(model.getSelectedPiece().move(i, j, model)){ //if the move is possible 
                                    if(model.findPiece(i, j) == null) { //if the piece isnt null
                                        Pieces Selected = model.getSelectedPiece(); //see if it move, king will get in check
                                        int selectedX = Selected.getTile().x;
                                        int selectedY = Selected.getTile().y;
                                        Selected.setTile(i, j);
                                        if(model.isKingChecked(Selected.getColor())){
                                          Selected.setTile(selectedX, selectedY);
                                        }
                                        else{ //if it's all right, set tile to green
                                            Selected.setTile(selectedX, selectedY);
                                            g.setStroke(new BasicStroke(4,CAP_BUTT,JOIN_MITER));
                                            g.setColor(Color.green);
                                            g.drawRect((i*50)+2, (j * 50)+2, 46, 46);
                                            model.addOverTiles(new Point(i,j));
                                        }
                                    } 
                                    else if(model.isEatable(i, j, model.getSelectedPiece())){ //check if the piece can eat and not get king into check
                                        Pieces Selected = model.getSelectedPiece();
                                        Pieces toBeEat = model.findPiece(i, j);
                                        int selectedX = Selected.getTile().x;
                                        int selectedY = Selected.getTile().y;
                                        toBeEat.setTile(8, 8);
                                        Selected.setTile(i, j);
                                        if (model.isKingChecked(Selected.getColor())){  
                                          Selected.setTile(selectedX, selectedY);
                                          toBeEat.setTile(i, j);
                                        } 
                                        else{ //if it's all right, set tile to blue
                                            Selected.setTile(selectedX, selectedY);
                                            toBeEat.setTile(i, j);
                                            g.setStroke(new BasicStroke(4,CAP_BUTT,JOIN_MITER));
                                            g.setColor(Color.blue);
                                            g.drawRect((i*50)+2, (j * 50)+2, 46, 46);
                                            model.addOverTilesEnemy(new Point(i,j));
                                        }            
                                    }    
                                }
                            }
                        }
                    }
                }
                this.testMove = false;
            }
            else { //if there's no need to recheck moves, just print out the vector 
               model.drawOverTiles(g);
               model.drawOverTilesEnemy(g);
               model.drawOver(new Point(model.getMouseCoord().x/50, model.getMouseCoord().y/50), g);
            }
        }
    }
    
    public void drawSelected(Graphics2D g) { //paints the tile of the selected piece as black
        Pieces selected = model.getSelectedPiece();
        if(selected!=null){
            g.setColor(Color.black);
            g.setStroke(new BasicStroke(4,CAP_BUTT,JOIN_MITER));
            g.drawRect((selected.getTile().x *50)+2, (selected.getTile().y * 50)+2, 46, 46);
        }
    }
    
    public void drawMouseTile(Graphics2D g) { //draw on tile that mouse is pointing to
        int width = 50;
        int height =50;
        int qx = model.getMouseCoord().x/width;
        int qy = model.getMouseCoord().y/height;
        if(qx<8 && qy<8){
            int squareWidth = 50;
            int squareHeight =50;
            g.setColor(Color.red);
            g.setStroke(new BasicStroke(4,CAP_BUTT,JOIN_MITER));
            g.drawRect((qx * squareWidth)+2, (qy * squareHeight)+2, (squareWidth)-4, (squareHeight)-4);
            g.setColor(Color.BLACK);
        }
    }
    

    /*------------------------------------------Check functions-----------------------------------*/

    public void isCheck(Pieces.Color teamChecking){
        Pieces.Color teamOverCheck;
        if (teamChecking == Pieces.Color.WHITE){
            teamOverCheck = Pieces.Color.BLACK;
        }
        else
            teamOverCheck = Pieces.Color.WHITE;
        if(!model.isKingChecked(teamOverCheck)){
            model.setChecked(false);
        }
        else{
            model.setChecked(true);
            if(model.isCheckMate(teamOverCheck)){
                System.out.println("chekmate");
                model.setCheckMate(true);
                this.TimerA.stop();
                this.TimerW.stop();
                this.TimerB.stop();
            }
        }
            return;
    }
    
    public void setPlayer1(Pieces.Color c){
        Player1 = c;
    }

    /*-----------------------------------------General actions--------------------------------*/

    public void initGameWhite(){
     
        gameover = false;
        model.newGameWhite();
        this.TimerA.stop();
        this.TimerB.stop();
        this.TimerW.stop();
        tA = new Point(0,0);
        this.setPlayer1(Pieces.Color.WHITE);
        TimerA = new timer(this, 0, tA);
        TimerA.start();
        TimerW = new timer(this, 1, new Point (0, gametype));
        TimerW.start();
        TimerB = new timer(this, 2, new Point (0, gametype));
        TimerB.start();
      
        view.resetLog();
        
         paintClocks();
        view.repaint();
    }
    
    public void initGameBlack(){
        gameover = false;
        model.newGameBlack();
        this.TimerA.stop();
        this.TimerW.stop();
        this.TimerB.stop();
        tA = new Point(0,0);
        
       this.setPlayer1(Pieces.Color.BLACK);
        TimerA = new timer(this, 0, tA);
        TimerA.start();
        TimerW = new timer(this, 1, new Point (0,gametype));
        TimerW.start();
        TimerB = new timer(this, 2, new Point (0,gametype));
        TimerB.start();
         view.resetLog();
         
         paintClocks();
         
        view.repaint();
    }

     public void LeaveAction(){
        model.Leave();
    }

    public void infoPanelAction(){
        view.infoPanel();
    }

    public void startMainWindow(){
        view.setVisible(true);
    }
    
    @Override
    public void mouseReleased(MouseEvent e) {
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
       
    }

    @Override
    public void mouseExited(MouseEvent e) {
        
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        model.getMouseCoord().setLocation(e.getX(), e.getY());
        view.repaint();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getActionCommand() == "Black")
            initGameBlack();
        else if(e.getActionCommand() == "White")
            initGameWhite();
        else if(e.getActionCommand() == "Leave")
            this.LeaveAction();
        else if(e.getActionCommand() == "Save game")
            this.saveGame();
         else if(e.getActionCommand() == "Load game")
            this.loadGame();
         else if(e.getActionCommand() == "On")
             this.enbAsave();
         else if(e.getActionCommand() == "Off")
             this.disAsave();
        else if(e.getActionCommand() == "15s")
             this.savetime(15);
        else if(e.getActionCommand() == "30s")
             this.savetime(30);
        else if(e.getActionCommand() == "60s")
             this.savetime(60);
        else if(e.getActionCommand() == "120s")
             this.savetime(120);
        else if(e.getActionCommand() == "1 min")
             this.setGameType(1);
        else if(e.getActionCommand() == "5 min")
             this.setGameType(5);
        else if(e.getActionCommand() == "10 min")
             this.setGameType(10);
        else if(e.getActionCommand() == "15 min")
             this.setGameType(15);
        else if(e.getActionCommand() == "30 min")
             this.setGameType(30);
        else if(e.getActionCommand() == "60 min")
             this.setGameType(60);
        else if(e.getActionCommand() == "120 min")
             this.setGameType(120);
         else if(e.getActionCommand() == "Set another")
             this.setSaveTime();
        
         
    }
    
    public void userSaveTime(){
        long x = Integer.parseInt(editTextArea.getText());
        savetime(x);
  //  this.savetime = x;
    }
    
    public void setSaveTime(){
        JFrame timeFrame = new JFrame();
        JPanel timePanel = new JPanel();
        timeFrame.setLocationRelativeTo(null);
        JButton chooseP = new JButton("Set");
        timePanel.add(editTextArea);
       editTextArea.setPreferredSize(new Dimension(100,30));
        timePanel.add(chooseP);
        chooseP.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                try{    
                userSaveTime();
                    timeFrame.dispose();
                }catch(Exception ex){
                
                }
                }
        
        
        });
        timeFrame.add(timePanel);
        
        timeFrame.pack();
        timeFrame.setVisible(true);
    
    
    }
    
    public void savetime(long i){
  
        savetime = i;
        enbAsave();
    }
    public void enbAsave(){
        if(Asave.isAlive())
            Asave.interrupt();
        
            Asave = new autosave(this, savetime);
            Asave.start();
    }
    
   public void disAsave(){
       Asave.interrupt();
   }
    
    public Pieces.Color getPlayer(){
        return model.getPlayer();
    }
    public Point getTimertA(){
        return tA;
    }
    
    public Point getTimertW(){
        return tW;
    }
    
    public Point getTimertB(){
        return tB;
    }
   
    public void loadGame(){
     
        if(TimerA.isAlive()){
        TimerA.stop();
        TimerB.stop();
        TimerW.stop();
        }
       
    FileInputStream f_in;
        try {
            f_in = new 
                    FileInputStream("save.data");
        
    ObjectInputStream obj_in;
        try {
            obj_in = new ObjectInputStream (f_in);
            model = (Chess) obj_in.readObject();
            view.registerBoardObserver(model);
            
            tA = model.gettA();
            tB = model.gettB();
            tW = model.gettW();
            if(model.getPlayer1() == Pieces.Color.WHITE){
            TimerA = new timer(this, 0, model.gettA());
            TimerA.start();
            
            TimerB = new timer(this, 2, model.gettB());
            TimerB.start();
            
            TimerW = new timer(this, 1, model.gettW());
            TimerW.start();
            }
            else{
            TimerA = new timer(this, 0, model.gettA());
            TimerA.start();
            
            TimerB = new timer(this, 2, model.gettW());
            TimerB.start();
            
            TimerW = new timer(this, 1, model.gettB());
            TimerW.start();
            }
            this.Player1 = model.getPlayer1();
            
            paintClocks();
            view.repaint();
            

    
        } catch (IOException ex) {
            Logger.getLogger(ChessController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ChessController.class.getName()).log(Level.SEVERE, null, ex);
        }

   
        
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ChessController.class.getName()).log(Level.SEVERE, null, ex);
        }

    
    
    }
    
    public void paintClocks(){
        
        if (this.getPlayer1() == Pieces.Color.BLACK){
                if(model.getPlayer()== Pieces.Color.BLACK){
                    view.setColorW(Color.red);
                    view.setColorB(Color.black);
               
                }
            else {
                view.setColorB(Color.red);
                view.setColorW(Color.black);
                
            }
        }
        else if(this.getPlayer1() == Pieces.Color.WHITE){
            if(model.getPlayer()== Pieces.Color.BLACK){
                view.setColorW(Color.black);
                view.setColorB(Color.red);
               
            }
            else{
                view.setColorB(Color.black);
                view.setColorW(Color.red);
                
            }
        }
       
    
    }
    
    public Pieces.Color getPlayer1(){
        return Player1;
    }
    public void attTimers(int t){
        tA.x = t;
        int t0;
        if (tA.x < 10){
            if (tA.y < 10)
                view.attTimerA("0"+String.valueOf(tA.y)+" : 0"+String.valueOf(tA.x) );
            else
                view.attTimerA(String.valueOf(tA.y)+" : 0"+String.valueOf(tA.x) );
        }
        else if(tA.y < 10)
            view.attTimerA("0"+String.valueOf(tA.y)+" : "+String.valueOf(tA.x) );
        else
            view.attTimerA(String.valueOf(tA.y)+" : "+String.valueOf(tA.x) );
        
    }
    
    public void attTimerm(int t){
        tA.y = t;
    }
    
    public void attTimerWs(int t){
        tW.x = t;
        int t0;
        if (tW.x < 10){
            if (tW.y < 10)
                view.attTimerW("0"+String.valueOf(tW.y)+" : 0"+String.valueOf(tW.x) );
            else
                view.attTimerW(String.valueOf(tW.y)+" : 0"+String.valueOf(tW.x) );
        }
        else if(tW.y < 10)
            view.attTimerW("0"+String.valueOf(tW.y)+" : "+String.valueOf(tW.x) );
        else
            view.attTimerW(String.valueOf(tW.y)+" : "+String.valueOf(tW.x) );
        
    }
    
    public void setGameType(int type){
        JOptionPane message = new JOptionPane();
        message.showMessageDialog(null, "You will need to start a new game to see the changes");
        gametype = type;
    }
    
    public void checkForSave(){
        TimerA.suspend();
        TimerW.suspend();
      
        File f = new File("save.data");
        if(f.exists() && !f.isDirectory()) { 
         
            
            int i = view.checkForLoad();
            if (i == JOptionPane.YES_OPTION){
                loadGame();
            }else{
                TimerA.resume();
                TimerW.resume();
            }
                
        
        }
        else{
        TimerA.resume();
                TimerW.resume();
        }
    }
    public void attTimerWm(int t){
        tW.y = t;
    }
    public void attTimerBs(int t){
        tB.x = t;
        int t0;
        if (tB.x < 10){
            if (tB.y < 10)
                view.attTimerB("0"+String.valueOf(tB.y)+" : 0"+String.valueOf(tB.x) );
            else
                view.attTimerB(String.valueOf(tB.y)+" : 0"+String.valueOf(tB.x) );
        }
        else if(tB.y < 10)
            view.attTimerB("0"+String.valueOf(tB.y)+" : "+String.valueOf(tB.x) );
        else
            view.attTimerB(String.valueOf(tB.y)+" : "+String.valueOf(tB.x) );
        
    }
    
    public void attTimerBm(int t){
        tB.y = t;
    }
    public void repaint(){
        view.repaint();
    }
  
    public void saveGame() {
        

       model.settA(tA);
       model.settW(tW);
       model.settB(tB);
       model.setPlayer1(this.Player1);
        
        FileOutputStream f_out;
        try {
            f_out = new 
                FileOutputStream("save.data");
            
        ObjectOutputStream obj_out;
        try {
            obj_out = new
                ObjectOutputStream (f_out);
            
        obj_out.writeObject ( model );
        } catch (IOException ex) {
        }
        } catch (FileNotFoundException ex) {
        }
            
        

   
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int id = e.getKeyChar();
       
        String keyString;
        if (id == KeyEvent.KEY_TYPED) {
            char c = e.getKeyChar();
            keyString = "key character = '" + c + "'";
        } else {
            int keyCode = e.getKeyCode();
            keyString = "key code = " + keyCode
                    + " ("
                    + KeyEvent.getKeyText(keyCode)
                    + ")";   
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }


    @Override
    public void mouseClicked(MouseEvent e) {
    }
    
    public void startWhiteTimer(){
        TimerW.resume();
    }
    
    public void startBlackTimer(){
        TimerB.resume();
    
    }
    
    public void stopWhiteTimer(){
       TimerW.suspend();
    }
    
        public void stopBlackTimer(){
            TimerB.suspend();
    }

    public void setGameover(){
        TimerA.suspend();
        gameover = true;
    }
    @Override
    public void mousePressed(MouseEvent e) {
        if(model.getCheckMate() || gameover){
            return;
        }
        boolean ate = false;
        int width = 50;
        int height =50;    
        Pieces piece = model.findPiece(e.getX() / width, e.getY() / height); //Find piece where clicked
       
        if(model.getSelectedPiece() == null){
            if(piece != null && piece.getColor() == model.getPlayer()){
                model.setSelectedPiece(piece);
                this.testMove = true;
            }
            else {
                new pieceException (model.getSelectedPiece());
                return;
            
            }
        }else {
            try{
                
                Pieces Selected = model.getSelectedPiece();
                int x = e.getX() / width;
                int y = e.getY() / height;
                if(model.getChecked()){ 
                    if( !model.canBlockTile(Selected.getColor(), Selected, x, y) &&
                        !model.canEatTile(Selected.getColor(),   Selected, x, y) &&
                         Selected.getClass() != King.class){
                            model.setSelectedPiece(null);
                            view.repaint();
                            return;
                    }
                }
                if(!model.isSameTile(x, y)){
                    if(Selected.move(x, y, model)){
                        if(model.findPiece(x, y) != null){
                            Pieces toBeEat = model.findPiece(x, y);
                            if(model.isEatable(x, y, Selected)){
                                int selectedX = Selected.getTile().x;
                                int selectedY = Selected.getTile().y;
                                toBeEat.setTile(8, 8);
                                Selected.setTile(x, y);
                                if (model.isKingChecked(Selected.getColor())){  
                                    Selected.setTile(selectedX, selectedY);
                                    toBeEat.setTile(x, y);
                                    return;
                                } 
                                else{
                                    Selected.setTile(selectedX, selectedY);
                                    toBeEat.setTile(x, y);
                                }
                                
                                model.deletePiece(x, y);
                                ate = true;
                            }
                            else{
                                model.setSelectedPiece(null);
                                view.repaint();
                                return;
                            }
                        }
                        int selectedX = Selected.getTile().x;
                        int selectedY = Selected.getTile().y;
                        Selected.setTile(x, y);
                        if(model.isKingChecked(Selected.getColor())){
                            Selected.setTile(selectedX, selectedY);
                            model.setSelectedPiece(null);
                            view.repaint();
                            return;
                        }
                        if(ate)
                            view.addNewLog(model.getSelectedPiece().getName()+"x"+((char)(model.getSelectedPiece().getTile().x+(int)'a'))+(-model.getSelectedPiece().getTile().y+8));
                        else
                            view.addNewLog(model.getSelectedPiece().getName()+((char)(model.getSelectedPiece().getTile().x+(int)'a'))+(-model.getSelectedPiece().getTile().y+8));
                        isCheck(Selected.getColor());
                        
                        if(model.getSelectedPiece().getClass() == Pawn.class){
                                Pawn pa = (Pawn) model.getSelectedPiece();
                                pa.promote(x, y, model, this, pa.getColor());
                               // view.repaint();
                             }
                        if(model.getPlayer()==Pieces.Color.WHITE) {
                            model.setPlayer(Pieces.Color.BLACK);
                            TimerW.suspend();
                            TimerB.resume();
                            paintClocks();
                        }
                        else {model.setPlayer(Pieces.Color.WHITE);
                            TimerB.suspend();
                            TimerW.resume();
                            paintClocks();
                        }
                    }
                    
                }
                
                model.setSelectedPiece(null);
            }catch(NullPointerException t ){
            }
        }
        view.repaint();
    }
}
