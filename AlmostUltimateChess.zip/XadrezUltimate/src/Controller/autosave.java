 
package Controller;

import Model.Chess;
import java.util.logging.Level;
import java.util.logging.Logger;

public class autosave extends Thread{
        private long t;
        private long stime;
        private ChessController controller;
        public autosave (ChessController con, long stime){
            t = System.currentTimeMillis();
            controller = con;
            this.stime = stime;
        }
        @Override
        public void run() {
            if(stime == 31){
            try {
                sleep(250);
            } catch (InterruptedException ex) {
               
            }
            controller.checkForSave();
            }
            while (!this.isInterrupted()){
                if(System.currentTimeMillis() - t > stime*1000){
                    controller.saveGame();
                    t = System.currentTimeMillis();
               
                }
              
           }
    
         }

    }