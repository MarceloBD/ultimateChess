/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Pieces.Pieces;

/**
 *
 * @author Lenovo
 */
public class pieceException{
    public pieceException(Pieces P){
        if(P == null){
            new pieceEx();
        }
    }
    class pieceEx extends Throwable{
        public pieceEx(){
            System.err.println("No piece selected");
        }
}
    
}
