package Controller;

import Pieces.Pieces;
import java.awt.Point;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;

public class timer extends Thread implements Serializable{
    private Point t;               // variable (seconds, minutes)
    private long now;               // time now
    private ChessController controller;
    private int n, type;
    
    public timer(ChessController con, int n, Point start) {
        controller = con;
        this.n = n;
        type = -1;
        t = start;
        if(n == 0){
            type = 1;
          
        }
       
    }
    
    @Override
    public void run() {
        now = System.currentTimeMillis();
        
        if(controller.getPlayer1() == Pieces.Color.WHITE){
        if (n == 0){
            controller.attTimerm(t.y);
            controller.attTimers(t.x);
        }
        else if (n == 1){
            controller.attTimerWm(t.y);
            controller.attTimerWs(t.x);
            if(controller.getPlayer() == Pieces.Color.BLACK)
              //  this.sleep(100);
                suspend();
        }
        else if (n == 2){
            controller.attTimerBm(t.y);
            controller.attTimerBs(t.x);
            if(controller.getPlayer() == Pieces.Color.WHITE)
                suspend();
        }}
        else{
        if (n == 0){
            controller.attTimerm(t.y);
            controller.attTimers(t.x);
            
        }
        else if (n == 1){
            controller.attTimerBm(t.y);
            controller.attTimerBs(t.x);
            
            if(controller.getPlayer() == Pieces.Color.BLACK)
                suspend();
        }
        else if (n == 2){
            controller.attTimerWm(t.y);
            controller.attTimerWs(t.x);
            
            if(controller.getPlayer() == Pieces.Color.WHITE)
                suspend();
        }
        }
        while(this.isAlive()){
            
            
            if(System.currentTimeMillis()- now >= 1000 ){
      
                
            now = System.currentTimeMillis();
                t.x = t.x + type;
                if(type ==1 ){
            if(t.x % 60 == 0){
                if(type == 1)
                    t.x = 0;
                t.y = t.y + type;
            }}
                else{
             
            
             if(t.x < 0 && type == -1){
                 if(t.y <= 0){
                     controller.setGameover();
                     this.suspend();
                 }
                t.y = t.y + type;
                 t.x = 59;
                
            }}
            if(controller.getPlayer1() == Pieces.Color.WHITE){
            if (n==0){
                controller.attTimerm(t.y);
                controller.attTimers(t.x);
                
            }
            else if (n == 1){
                controller.attTimerWm(t.y);
                controller.attTimerWs(t.x);
                
            }
            else if (n == 2){
                controller.attTimerBm(t.y);
            controller.attTimerBs(t.x);
            
        }
            }
            else{
            if (n==0){
                controller.attTimerm(t.y);
                controller.attTimers(t.x);
                
            }
            else if (n == 1){
                controller.attTimerBm(t.y);
                controller.attTimerBs(t.x);
                
            }
            else if (n == 2){
                controller.attTimerWm(t.y);
            controller.attTimerWs(t.x);
            
            
            }
        }
        }
    }   
}}
