/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Pieces.Bishop;
import Pieces.King;
import Pieces.Knight;
import Pieces.Pawn;
import Pieces.Pieces;
import Pieces.Pieces.Color;
import Pieces.Queen;
import Pieces.Rook;
import java.awt.Graphics2D;
import java.awt.Point;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Observable;
import java.util.Observer;


public class Chess implements Serializable, Observer{
    
    private ArrayList<Pieces> blackPieces;
    private ArrayList<Pieces> whitePieces;
    private ArrayList<Point> overTiles;
    private ArrayList<Point> overTilesEnemy;
    private Point mouseCoord;
    private Point mouseOverTile;    
    private Pieces selectedPiece = null;
    private Color player; 
    private boolean checked;
    private boolean checkMate = false;
    private Point tA, tB, tW;
    private Color Player1;
    
    public Chess(){
        this.blackPieces = new ArrayList<Pieces>();
        this.whitePieces  = new ArrayList<Pieces>();
        mouseCoord = new Point();
        mouseOverTile = new Point();
        this.overTiles = new ArrayList<Point>();
        this.overTilesEnemy = new ArrayList<Point>();
        initWhite();
    }
    public void settA(Point t){
        tA = t;
    }
   
    
    public Point gettA(){
        return tA;
    }
    public void settW(Point t){
        tW = t;
    }
   
    public Point gettW(){
        return tW;
    }
    public void settB(Point t){
        tB = t;
    }
   
    public Point gettB(){
        return tB;
    }
    public void newGameWhite(){
        blackPieces = new ArrayList<Pieces>();
        whitePieces = new ArrayList<Pieces>();
        cleanOverTilesEnemy();
        setSelectedPiece(null);
        this.setChecked(false);
        this.setCheckMate(false);
        initWhite();
    }
    
    public void newGameBlack(){
        blackPieces = new ArrayList<Pieces>();
        whitePieces = new ArrayList<Pieces>();
        this.setCheckMate(false);
        this.setChecked(false);
        cleanOverTilesEnemy();
        setSelectedPiece(null);
        initBlack();
    }
    
    /*
      Inits the game as white team  
    */
    private void initWhite(){
        player = Color.WHITE;
        
        whitePieces.add(new Pawn(Pieces.Color.WHITE,0,6,1));
        whitePieces.add(new Pawn(Pieces.Color.WHITE,1,6,1));
        whitePieces.add(new Pawn(Pieces.Color.WHITE,2,6,1));
        whitePieces.add(new Pawn(Pieces.Color.WHITE,3,6,1));
        whitePieces.add(new Pawn(Pieces.Color.WHITE,4,6,1));
        whitePieces.add(new Pawn(Pieces.Color.WHITE,5,6,1));
        whitePieces.add(new Pawn(Pieces.Color.WHITE,6,6,1));
        whitePieces.add(new Pawn(Pieces.Color.WHITE,7,6,1));
        
        whitePieces.add(new Knight(Pieces.Color.WHITE,1,7));
        whitePieces.add(new Knight(Pieces.Color.WHITE,6,7));
        
        whitePieces.add(new King(Pieces.Color.WHITE,4,7));
        whitePieces.add(new Queen(Pieces.Color.WHITE,3,7));
        
        whitePieces.add(new Bishop(Pieces.Color.WHITE,2,7));
        whitePieces.add(new Bishop(Pieces.Color.WHITE,5,7));
        
        whitePieces.add(new Rook(Pieces.Color.WHITE,0,7));
        whitePieces.add(new Rook(Pieces.Color.WHITE,7,7));
        
        blackPieces.add(new Pawn(Pieces.Color.BLACK,0,1,1));
        blackPieces.add(new Pawn(Pieces.Color.BLACK,1,1,1));
        blackPieces.add(new Pawn(Pieces.Color.BLACK,2,1,1));
        blackPieces.add(new Pawn(Pieces.Color.BLACK,3,1,1));
        blackPieces.add(new Pawn(Pieces.Color.BLACK,4,1,1));
        blackPieces.add(new Pawn(Pieces.Color.BLACK,5,1,1));
        blackPieces.add(new Pawn(Pieces.Color.BLACK,6,1,1));
        blackPieces.add(new Pawn(Pieces.Color.BLACK,7,1,1));
        
        blackPieces.add(new Knight(Pieces.Color.BLACK,1,0));
        blackPieces.add(new Knight(Pieces.Color.BLACK,6,0));
        
        blackPieces.add(new King(Pieces.Color.BLACK,4,0));
        blackPieces.add(new Queen(Pieces.Color.BLACK,3,0));
        
        
        blackPieces.add(new Bishop(Pieces.Color.BLACK,2,0));
        blackPieces.add(new Bishop(Pieces.Color.BLACK,5,0));
 
        
        blackPieces.add(new Rook(Pieces.Color.BLACK,0,0));
        blackPieces.add(new Rook(Pieces.Color.BLACK,7,0));
    }
    
    /*
        Inits the game as black team
    */
     private void initBlack(){
        player = Color.WHITE;
 
        blackPieces.add(new Pawn(Pieces.Color.BLACK,0,6,-1));
        blackPieces.add(new Pawn(Pieces.Color.BLACK,1,6,-1));
        blackPieces.add(new Pawn(Pieces.Color.BLACK,2,6,-1));
        blackPieces.add(new Pawn(Pieces.Color.BLACK,3,6,-1));
        blackPieces.add(new Pawn(Pieces.Color.BLACK,4,6,-1));
        blackPieces.add(new Pawn(Pieces.Color.BLACK,5,6,-1));
        blackPieces.add(new Pawn(Pieces.Color.BLACK,6,6,-1));
        blackPieces.add(new Pawn(Pieces.Color.BLACK,7,6,-1));
        
        blackPieces.add(new Knight(Pieces.Color.BLACK,1,7));
        blackPieces.add(new Knight(Pieces.Color.BLACK,6,7));
        
        blackPieces.add(new King(Pieces.Color.BLACK,3,7));
        blackPieces.add(new Queen(Pieces.Color.BLACK,4,7));
        
        blackPieces.add(new Bishop(Pieces.Color.BLACK,2,7));
        blackPieces.add(new Bishop(Pieces.Color.BLACK,5,7));
        
        blackPieces.add(new Rook(Pieces.Color.BLACK,0,7));
        blackPieces.add(new Rook(Pieces.Color.BLACK,7,7));
        
        whitePieces.add(new Pawn(Pieces.Color.WHITE,0,1,-1));
        whitePieces.add(new Pawn(Pieces.Color.WHITE,1,1,-1));
        whitePieces.add(new Pawn(Pieces.Color.WHITE,2,1,-1));
        whitePieces.add(new Pawn(Pieces.Color.WHITE,3,1,-1));
        whitePieces.add(new Pawn(Pieces.Color.WHITE,4,1,-1));
        whitePieces.add(new Pawn(Pieces.Color.WHITE,5,1,-1));
        whitePieces.add(new Pawn(Pieces.Color.WHITE,6,1,-1));
        whitePieces.add(new Pawn(Pieces.Color.WHITE,7,1,-1));
        
        whitePieces.add(new Knight(Pieces.Color.WHITE,1,0));
        whitePieces.add(new Knight(Pieces.Color.WHITE,6,0));
        
        whitePieces.add(new King(Pieces.Color.WHITE,3,0));
        whitePieces.add(new Queen(Pieces.Color.WHITE,4,0));
        
        
        whitePieces.add(new Bishop(Pieces.Color.WHITE,2,0));
        whitePieces.add(new Bishop(Pieces.Color.WHITE,5,0));
 
        
        whitePieces.add(new Rook(Pieces.Color.WHITE,0,0));
        whitePieces.add(new Rook(Pieces.Color.WHITE,7,0));
    }

     public void promote(Pieces p, Pieces n){
         for (Pieces q:whitePieces ){
  
             try{
             if (q.getTile().equals(p.getTile())){
                 System.out.println("heeeeeeeeeeeeeeeeeeeeeeeeeee");
                 deletePiece(p.getTile().x, p.getTile().y);
                 q = n;
                 whitePieces.add(q);
                 break;
             }
             }catch(Exception e){
             }
         }
         
         for (Pieces q:blackPieces ){
  
             try{
             if (q.getTile().equals(p.getTile())){
                // System.out.println("heeeeeeeeeeeeeeeeeeeeeeeeeee");
                 deletePiece(p.getTile().x, p.getTile().y);
                 q = n;
                 blackPieces.add(q);
                 break;
             }
             }catch(Exception e){
             }
         }
     
     }
     
     
    /*----------------------Add overtiles (paint tiles that piece can walk over)--------------------*/
    public void addOverTiles(Point overTiles){
        this.overTiles.add(overTiles);
    }
    
    public void cleanOverTiles(){
        this.overTiles = new ArrayList<Point>();
    }
    
    public void drawOverTiles(Graphics2D g){
        for(Point p : overTiles){           
            g.setColor(java.awt.Color.GREEN);
            g.drawRect((p.x*50)+2, (p.y*50)+2, 46, 46);   
        }
    }
    
     public void addOverTilesEnemy(Point overTilesEnemy){
        this.overTilesEnemy.add(overTilesEnemy);
    }
    
    public void cleanOverTilesEnemy(){
        this.overTilesEnemy = new ArrayList<Point>();
    }
    
    public void drawOverTilesEnemy(Graphics2D g){   
        for(Point p : overTilesEnemy){
            g.setColor(java.awt.Color.BLUE);
            g.drawRect((p.x*50)+2, (p.y*50)+2, 46, 46);
        }
    }
    
    public void drawOver(Point tile, Graphics2D g){
        for(Point p : overTiles){
           if(p.equals(tile)){
                g.setColor(java.awt.Color.YELLOW);
                g.drawRect((p.x*50)+2, (p.y*50)+2, 46, 46);
           }
        }
        for(Point p : overTilesEnemy){
           if(p.equals(tile)){
                g.setColor(java.awt.Color.YELLOW);
                g.drawRect((p.x*50)+2, (p.y*50)+2, 46, 46);
           }
        }
    }
     
    /*-----------------------------------Check checkmate and checks------------------------------------*/
    public boolean getCheckMate(){
        return checkMate;
    }
    
    public void setCheckMate(boolean Check){
        this.checkMate = Check;
    }
    
    public boolean getChecked(){
         return checked;
     }
     
     public void setChecked(Boolean checked){
         this.checked = checked;
     }
     
    public boolean canBlockTile(Color teamOverCheck, Pieces p, int x, int y){
       ArrayList<Pieces> checking = this.getTeamChecking(teamOverCheck);
         for (Pieces check: checking){
            if (check.move(x, y, this)){
              if(p.move(x, y, this)){
                int px = p.getTile().x;
                int py = p.getTile().y;
                p.setTile(x, y);
                if(!this.isKingChecked(teamOverCheck)){
                  System.out.println("Jogada valida: A peça "+p+"pode entrar na frente em"+x+ " "+y);
                   p.setTile(px, py);
                   return true;
                }  
                p.setTile(px, py);
              }
            }
        }
     return false;
    }

    public boolean canEatTile(Color teamOverCheck, Pieces p, int x, int y){
        ArrayList<Pieces> piecesChecking = this.getPiecesChecking(teamOverCheck);
        ListIterator listIterator = piecesChecking.listIterator();
        if(!listIterator.hasNext()){
            return false;
        }
        for(Pieces checkP: piecesChecking){ 
            listIterator.next();
            if (checkP.getTile().x == x && checkP.getTile().y == y){
                int px = p.getTile().x;
                int py = p.getTile().y;
                checkP.setTile(8, 8);
                p.setTile(x, y);                
                if(this.isKingChecked(teamOverCheck)){
                  p.setTile(px, py);
                  checkP.setTile(x, y);
                  listIterator.remove();
                }
                else{
                  p.setTile(px, py);
                  checkP.setTile(x, y);
                  System.out.println("peça q vai matar"+p+"peça dando cheque"+checkP);            
                  return true;
                }
              }
              if(!listIterator.hasNext()){
                return false;
              }
        }
            return false;
    }

     public boolean canEatForKing(Color teamOverCheck, Pieces p){
    //    ArrayList<Pieces> overCheck = this.getTeamOverCheck(teamOverCheck);
        ArrayList<Pieces> piecesChecking = this.getPiecesChecking(teamOverCheck);
        ListIterator listIterator= piecesChecking.listIterator();
        if(!listIterator.hasNext()){
            return false;
        }
        for(Pieces checkP: piecesChecking){ 
            listIterator.next();
            if (p.move(checkP.getTile().x, checkP.getTile().y, this)){
                    int px = p.getTile().x;
                    int py = p.getTile().y;
                    int checkPx = checkP.getTile().x;
                    int checkPy = checkP.getTile().y;
                    checkP.setTile(8, 8);
                    p.setTile(checkPx, checkPy);
                     if(this.isKingChecked(teamOverCheck)){
                        p.setTile(px, py);
                        checkP.setTile(checkPx, checkPy);
                        listIterator.remove();
                    }
                    else{
                        p.setTile(px, py);
                        checkP.setTile(checkPx, checkPy);
                        System.out.println("peça q vai matar"+p+"peça dando cheque"+checkP);            
                        return true;
                    }
            }
            if(!listIterator.hasNext()){
                return false;
            }
        }
        return false;
     }
     
     public boolean canBlockCheck(Color teamOverCheck, Pieces p){
         ArrayList<Pieces> checking = this.getTeamChecking(teamOverCheck);
         int i, j;
         for (Pieces check: checking){
            for (i=0; i<8; i++){
                for (j=0; j<8; j++){
                    if (check.move(i, j, this)){
                        if(p.move(i, j, this)){
                             int px = p.getTile().x;
                             int py = p.getTile().y;
                             p.setTile(i, j);
                             if(!this.isKingChecked(teamOverCheck)){
                                System.out.println("A peça "+p+"pode entrar na frente em"+i);
                                p.setTile(px, py);
                                return true;
                            }  
                            p.setTile(px, py);
                          }
                     }
                 }
            }
         }
         return false;
     }
     
     public Pieces findKing(Color teamOverCheck){
         ArrayList<Pieces> overCheck = this.getTeamOverCheck(teamOverCheck);
         for(Pieces p: overCheck){
            if( p.getClass() == King.class){
                return p; 
            }
        }
        return null;
     }
     
    public ArrayList<Pieces> getPiecesChecking(Color teamOverCheck){
      ArrayList<Pieces> checking = this.getTeamChecking(teamOverCheck);
      ArrayList<Pieces> checked = new ArrayList<Pieces>();
      Pieces king = this.findKing(teamOverCheck);
      for(Pieces p: checking){
        if (p.move(king.getTile().x, king.getTile().y, this)){
          checked.add(p);
        }
      }
      return checked;
     }
     
    public ArrayList getTeamChecking(Color teamOverCheck){
      ArrayList<Pieces> checking = new ArrayList<Pieces>();
      if (teamOverCheck == Color.BLACK){
        checking = whitePieces;
      }
      else{
        checking = blackPieces;
      }
      return checking;
    }
     
    public ArrayList getTeamOverCheck(Color teamOverCheck){
      ArrayList<Pieces> overCheck = new ArrayList<Pieces>();
      if (teamOverCheck == Color.BLACK){
        overCheck = blackPieces;
      }
      else{
        overCheck = whitePieces;
      }
      return overCheck;
    }
     
    public boolean isCheckMate(Color teamOverCheck){
      ArrayList<Pieces> overCheck = this.getTeamOverCheck(teamOverCheck);
      boolean mate = true;
      int i, j;
      System.out.println("calling checkmate");
      Pieces king = this.findKing(teamOverCheck);
      for (i=0; i<8; i++){
        for (j=0; j<8; j++){
          if(king.move(i, j, this)){    
            System.out.println("king can walk"+i+" "+j);
            if( this.findPiece(i,j) != null && this.findPiece(i,j).getColor() == teamOverCheck){
              mate = true;
            }
            else {
              int kingx = king.getTile().x;
              int kingy = king.getTile().y;
              boolean eat;
              Pieces toBeEat;
              if (this.findPiece(i, j) == null){
                  eat = false;
                  toBeEat = null;
              }
              else {
                eat = true;
                toBeEat = this.findPiece(i, j);
                toBeEat.setTile(8, 8);
              }
              king.setTile(i, j);
              if(this.isKingChecked(teamOverCheck)){
                mate = true;
                king.setTile(kingx, kingy);
                if (eat){
                  toBeEat.setTile(i,j);
                }
                System.out.println("isChecktrue"+i+" "+j);
              }
              else{
                System.out.println("isCheckFALSE"+i+" "+j);
                mate = false;
                king.setTile(kingx, kingy);
                if (eat){
                  toBeEat.setTile(i,j);
                }
                return mate;
              }   
            }
          }
          else 
            System.out.println("king cant walk"+i+" "+j);
        }
      }   
      if (mate == true){
             for (Pieces p: overCheck){
                if(this.canEatForKing(teamOverCheck, p))
                    return false;
                }
             }
         if(mate == true){
             for (Pieces p: overCheck){
                if(this.canBlockCheck(teamOverCheck, p)){
                    return false;
                }
             
             }
         }
           
         return mate;
     }
  
     public boolean isCheck(Color teamOverCheck, int x, int y){
        ArrayList<Pieces> checking = this.getTeamChecking(teamOverCheck);
        for (Pieces p: checking){
           // System.out.println("==++++=="+p.getClass());
            if (p.move(x, y, this)){
             //   System.out.println("========"+p.getClass());
                return true;
            }
        }
        return false;
     }
        
    public boolean isKingChecked(Color teamOverCheck){
      Pieces king = this.findKing(teamOverCheck);
      if(isCheck(teamOverCheck, king.getTile().x, king.getTile().y))
        return true;
      else
        return false;
    }
    
    /*----------------Mouse postion controll------------------*/
    public Point getMouseCoord() {
        return mouseCoord;
    }

    public void setMouseCoord(Point mouseCoord) {
        this.mouseCoord = mouseCoord;
    }

    public Point getMouseOverTile() {
        return mouseOverTile;
    }

    public void setMouseOverTile(Point mouseOverTile) {
        this.mouseOverTile = mouseOverTile;
    }
    
    
    /*------------------Pieces controll-----------------------*/
    
    public void setSelectedPiece(Pieces selectedPiece) {
        this.selectedPiece = selectedPiece;
    }
    
    public Pieces getSelectedPiece() {
        return selectedPiece;
    }

    
    public Color getPlayer() {
        return player;
    }
    
    public  void setPlayer(Color player){
        this.player=player;
    }
 
    public Pieces findPiece(int x, int y) {
        Pieces pieces = null;
        
        for(Pieces p : whitePieces){
            if(p.inSquare(x, y)){
                return p;
            }
        }
        for(Pieces p : blackPieces){
            if(p.inSquare(x, y)){
                return p;
            }
        }
        return pieces;
    }

    public boolean isEatable(int x, int y, Pieces piece){
            if(this.findPiece(x, y) != null && this.findPiece(x, y).getColor() != piece.getColor()){    
                return true;
            }
            else
                return false;
    }    
    
    public boolean isSameTile(int x, int y){
        if(this.getSelectedPiece().getTile().x == x && this.getSelectedPiece().getTile().y ==y){
            return true;
        }
        else 
            return false;
    }
    
   public void deletePiece(int x, int y){
        Pieces pieces = null;     
        ListIterator listIterator1= whitePieces.listIterator();
        for(Pieces p : whitePieces){
                listIterator1.next();
            if(p.inSquare(x,y)){
                listIterator1.remove();
                return;
            }
        }
        ListIterator listIterator2= blackPieces.listIterator();
        for(Pieces p : blackPieces){
            listIterator2.next();
            if(p.inSquare(x,y)){
                listIterator2.remove();
                return;
            }            
        }
   }
   
   /*-----------------------------General controll--------------------------*/ 
    public void draw(Graphics2D g){
        for(Pieces p : whitePieces){
            p.draw(g);
        }
        for(Pieces p : blackPieces){
            p.draw(g);
        }
    }

   public boolean Leave(){
       System.exit(0);
       return true;
   }
   
   
    @Override
    public void update(Observable o, Object arg) {
        draw((Graphics2D) arg);
    }

    public void setPlayer1(Color Player1) {
        this.Player1 = Player1;
    }

    public Color getPlayer1(){
        return Player1;
    }
  

    
}
