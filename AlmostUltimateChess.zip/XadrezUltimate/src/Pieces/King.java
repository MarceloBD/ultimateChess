/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pieces;

import Model.Chess;
import java.awt.Graphics2D;

/**
 *
 * @author Lenovo
 */
public class King extends Pieces{

    public King(Color color, int x, int y) {
        super(color, x, y);
    }

    @Override
    public void draw(Graphics2D g) {
     int squareWidth = 50;
        int squareHeight =50;
      
        int x0 = tile.x * squareWidth;
        int y0 = tile.y * squareHeight;
        int x1 = x0 + squareWidth;
        int y1 = y0 + squareHeight;
        
        if(this.color == Pawn.Color.BLACK){
            g.drawImage(piecesImg, x0, y0, x1, y1, 20, 374, 315, 650, null);
        } else {
            g.drawImage(piecesImg, x0, y0, x1, y1, 20, 40, 315, 314, null);
        } 
    }

    @Override
    public boolean move(int x, int y, Chess model) {
        if(this.tile.x+1==x && this.tile.y+1==y || this.tile.x+1==x && this.tile.y==y || this.tile.x+1==x && this.tile.y-1==y || this.tile.x-1==x && this.tile.y+1==y || this.tile.x-1==x && this.tile.y==y || this.tile.x-1==x && this.tile.y-1==y || this.tile.x==x && this.tile.y+1==y || this.tile.x==x && this.tile.y-1==y){
     //       int posX, posY;
       //     posX = this.getTile().x;
         //   posY = this.getTile().y;
           // if(model.findPiece(x, y) == null){
             //   this.setTile(x, y);
//                if (model.isKingChecked(this.getColor())){
  //                  this.setTile(posX, posY);
    //                return false;
      //          }
        //        else {
          //          this.setTile(posX, posY);
            //        return true;
              //  }
//            }
  //          else if(model.canEatTile(this.getColor(), this, x, y)){
      //          Pieces toBeEat = model.findPiece(x, y);
    //            toBeEat.setTile(8, 8);
        //        this.setTile(x, y);
          //      if (model.isKingChecked(this.getColor())){
            //        this.setTile(posX, posY);
              //      toBeEat.setTile(x, y);
                //    return false;
  //              }
    //            else {
      //              this.setTile(posX, posY);
        //            toBeEat.setTile(x, y);
                    return true;
          //      }
          //  }
        }
        return false;
}

    @Override
    public String getName() {
        return "K";
    }
}