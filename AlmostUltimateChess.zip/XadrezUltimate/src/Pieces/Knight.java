/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pieces;

import Model.Chess;
import java.awt.Graphics2D;

/**
 *
 * @author Lenovo
 */
public class Knight extends Pieces {

    public Knight(Color color, int x, int y) {
        super(color, x, y);
    }

    @Override
    public void draw(Graphics2D g) {
        int squareWidth = 50;
        int squareHeight =50;
      
        int x0 = tile.x * squareWidth;
        int y0 = tile.y * squareHeight;
        int x1 = x0 + squareWidth;
        int y1 = y0 + squareHeight;
        
        if(this.color == Pawn.Color.BLACK){
            g.drawImage(piecesImg, x0, y0, x1, y1, 1015, 374, 1310, 650, null);
        } else {
            g.drawImage(piecesImg, x0, y0, x1, y1, 1015, 40, 1310, 314, null);
        }
    }

    @Override
    public boolean move(int x, int y, Chess model) {
       // System.out.println("cavalo mexendo");
     //  if( model.getChecked() && model.canBlockTile(this.getColor(), this, x, y) || model.getChecked() && model.canEatTile(this.getColor(), this, x, y) || !model.getChecked()){
        if(     this.tile.x + 2 == x && this.tile.y + 1 == y || 
                this.tile.x + 2 == x && this.tile.y - 1 == y ||
                this.tile.x + 1 == x && this.tile.y + 2 == y ||
                this.tile.x + 1 == x && this.tile.y - 2 == y ||
                this.tile.x - 1 == x && this.tile.y + 2 == y || 
                this.tile.x - 1 == x && this.tile.y - 2 == y ||
                this.tile.x - 2 == x && this.tile.y + 1 == y ||
                this.tile.x - 2 == x && this.tile.y - 1 == y ){
            return true; 
        }
        else return false;
    //}
    // else return false;
}

    @Override
    public String getName() {
        return "N";
    }
}