package Pieces;

import Controller.ChessController;
import Model.Chess;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRootPane;

public class Pawn extends Pieces{

    private int boardSide = 1;
    
    public Pawn(Color color, int x, int y, int side)  {
        super(color, x, y);
     
        if (side == 1)
            boardSide = 1;
        else
            boardSide = -1;
    
        
    }

    @Override
    public void draw(Graphics2D g) {
        int squareWidth = 50;
        int squareHeight =50;
      
        int x0 = tile.x * squareWidth;
        int y0 = tile.y * squareHeight;
        int x1 = x0 + squareWidth;
        int y1 = y0 + squareHeight;
        
        if(this.color == Pawn.Color.BLACK){
            g.drawImage(piecesImg, x0, y0, x1, y1, 1700, 374, 1960, 650, null);
        } else {
            g.drawImage(piecesImg, x0, y0, x1, y1, 1700, 40, 1960, 314, null);
        }
    }
    
    @Override
    public String toString() {
        if(this.color == Pieces.Color.BLACK){
            return "Peao Preta"+ "("+ tile.x + ","+tile.y+")";
        } else {
            return "Peao Branca"+ "("+ tile.x + ","+tile.y+")";
        }
    }
    
   

    @Override
    public boolean move(int x, int y, Chess model) {
        
        int side;
        if(this.color == Pieces.Color.BLACK)
            side = 1*boardSide;
        else
            side = -1*boardSide;
        
        /*Checks if it can get a piece*/
        if(tile.x + 1 == x && tile.y + side == y|| tile.x - 1 == x && tile.y + side == y){
            
            if(model.findPiece(x, y) !=null && model.findPiece(x, y).color != this.color){
           // promote(x, y);
            return true;
            }
            else return false;
            
        }
        /*Checks if there is a piece in front of it*/
        if(model.findPiece(x, tile.y+side)!=null){
                    return false;
                }
        
        /*Checks if it is the first move*/
        if(tile.y==1 || tile.y==6 ){
            if(tile.x==x && tile.y+2*side==y){
                if(model.findPiece(x, tile.y+side)!=null || model.findPiece(x, tile.y+2*side)!=null){
                    return false;
                }
          //      promote(x, y);
                return true;
            }
        }
        
        /*Makes the pawn walk */
        if(tile.x == x && tile.y + side == y){
        //promote(x, y);
            return true;
        }   
        else
            return false;
        }

    @Override
    public String getName() {
        return "";
    }
    
    public void promote(int x, int y, Chess model, ChessController controller, Pieces.Color col){
        if(y==0 || y==7){
            JFrame prom = new JFrame();
            

//prom.setUndecorated(true);
//prom.getRootPane().setWindowDecorationStyle(JRootPane.NONE);
            //prom.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            prom.setLocationRelativeTo(null);
            prom.setResizable(false);
            JPanel panel = new JPanel();
            //prom.setSize(new Dimension(100,200));
            JButton chooseP = new JButton("Queen");
            chooseP.setSize(100, 100);
            chooseP.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                    // System.out.println("queen");
                     if(col == Pieces.Color.WHITE)
                     model.promote(new Pawn(Pieces.Color.WHITE, x, y, 1), new Queen(Pieces.Color.WHITE, x, y));
                     else
                     model.promote(new Pawn(Pieces.Color.BLACK, x, y, 1), new Queen(Pieces.Color.BLACK, x, y));
                     prom.dispose();
                     controller.repaint();
                }
                
            
            
            });
            panel.add(chooseP);
            
            chooseP = new JButton("Rook");
            chooseP.setSize(100, 100);
            chooseP.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                    
                     if(col == Pieces.Color.WHITE)
                     model.promote(new Pawn(Pieces.Color.WHITE, x, y, 1), new Rook(Pieces.Color.WHITE, x, y));
                     else
                     model.promote(new Pawn(Pieces.Color.BLACK, x, y, 1), new Rook(Pieces.Color.BLACK, x, y));
                     prom.dispose();
                      controller.repaint();
                }
            });
            panel.add(chooseP);
            chooseP = new JButton("Knight");
            chooseP.setSize(100, 100);
            chooseP.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                    if(col == Pieces.Color.WHITE)
                     model.promote(new Pawn(Pieces.Color.WHITE, x, y, 1), new Knight(Pieces.Color.WHITE, x, y));
                     else
                     model.promote(new Pawn(Pieces.Color.BLACK, x, y, 1), new Knight(Pieces.Color.BLACK, x, y));
                     prom.dispose();
                      controller.repaint();
                }
            });
            panel.add(chooseP);
            chooseP = new JButton("Bishop");
            chooseP.setSize(100, 100);
            chooseP.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                    if(col == Pieces.Color.WHITE)
                     model.promote(new Pawn(Pieces.Color.WHITE, x, y, 1), new Bishop(Pieces.Color.WHITE, x, y));
                     else
                     model.promote(new Pawn(Pieces.Color.BLACK, x, y, 1), new Bishop(Pieces.Color.BLACK, x, y));
                     prom.dispose();
                      controller.repaint();
                }
            });
            panel.add(chooseP);
           
            prom.add(panel);
            prom.setVisible(true);
            prom.pack();
        }
    
    }
    
    
    }

    

