package Pieces;

import Model.Chess;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

public abstract class Pieces implements Serializable {

    protected final static String imgPath = "src/Pieces/img.png";    // Path of the source image for all pieces
    protected static BufferedImage piecesImg = null;                 // Buffer for the image 
    protected Color color;                                           // Color of the pieces
    protected Point tile;                                            // Tile of each piece will occuppy
 
    public enum Color{                                               // Declaration of color property  
        BLACK,
        WHITE
    }
        
    public Pieces(Color color, int x, int y){
        this.color = color;                                                     // Receives the color 
        this.tile = new Point(x,y);                                             // Receives the position
        InputStream is = this.getClass().getResourceAsStream("img.png");        
        if(piecesImg == null){
            try {
                piecesImg = ImageIO.read(is);
            } catch (IOException ex) {
                Logger.getLogger(Pieces.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }
   
    public boolean inSquare(int x, int y){
        if(x == tile.x && y == tile.y) return true;
        else return false;
    }
    
    public void setTile(int x, int y){
        tile.setLocation(x, y);
    }
 
    public Point getTile(){
        return tile;
    }
    
    public Color getColor(){
        return color;
    }
    
            
    public abstract void draw(Graphics2D g);
    
    public abstract boolean move(int x, int y, Chess model);

    public abstract String getName();
}

