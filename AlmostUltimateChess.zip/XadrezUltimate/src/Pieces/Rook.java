/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pieces;

import Model.Chess;
import java.awt.Graphics2D;

/**
 *
 * @author Lenovo
 */
public class Rook extends Pieces {

    public Rook(Color color, int x, int y) {
   super(color,x,y); }

    @Override
    public void draw(Graphics2D g) {
    int squareWidth = 50;
        int squareHeight =50;
      
        int x0 = tile.x * squareWidth;
        int y0 = tile.y * squareHeight;
        int x1 = x0 + squareWidth;
        int y1 = y0 + squareHeight;
        
        if(this.color == Pawn.Color.BLACK){
            g.drawImage(piecesImg, x0, y0, x1, y1, 1370, 374, 1630, 650, null);
        } else {
            g.drawImage(piecesImg, x0, y0, x1, y1, 1370, 40, 1630, 314, null);
        } }

    @Override
    public boolean move(int x, int y, Chess model) {
        
        int i,j;
        
        
        /*Checks if it's moving in y- axis*/
         if (this.tile.x == x  && this.tile.y > y){
            for(i = tile.y - 1; i > y; i--){
                if(model.findPiece(x, i) != null){
                    return false;
                }    
            }
            return true;
        }
        
        /*Checks if it's moving in y+ axis*/
        else if (this.tile.x == x  && this.tile.y < y){
            for(i = tile.y + 1; i < y; i++){
                if(model.findPiece(x, i) != null){
                    return false;
                }
            }
            return true;
        }
        
        /*Checks if it's moving in x+ axis*/
        else if (this.tile.y == y  && this.tile.x < x){
            for(i = tile.x + 1; i < x; i++){
                if(model.findPiece(i, y) != null){
                    return false;
                }
            }
            return true;
        }
        
        /*Checks if it's moving in x- axis*/
        else if (this.tile.y == y  && this.tile.x > x){
            for(i = tile.x - 1; i > x; i--){
                if(model.findPiece(i, y) != null){
                    return false;
                }
            }
            return true;
        }
        else
              return false;
    }

    @Override
    public String getName() {
        return "R";
    }
}
