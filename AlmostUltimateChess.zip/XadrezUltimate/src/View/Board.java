/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import Model.Chess;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.Observer;
import javax.swing.JPanel;


public class Board extends JPanel{

    private ArrayList<Observer> observers;
    
    public Board() {
        super();
      this.setSize(400, 400);
        
        observers = new ArrayList<Observer>();
    }
    
    public void registerObserver(Observer ob){
        this.observers.add(ob);
    }
    
    public void deleteObserver(){
        this.observers.remove(1);
    }
    
    /*Paints the board*/
    private void drawBoard(Graphics2D g){
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {        
                    if ((j+i) % 2 == 0) g.setColor(Color.white);
                    else g.setColor(Color.gray);
                    g.fillRect(j * 50, i*50, 50, 50);
                }
            }
    }
    
    /*Method to override paintComponent of JPanel class */
    @Override
    protected void paintComponent(Graphics g) {
        
        super.paintComponent(g);      
        Graphics2D g2 = (Graphics2D)g;
        drawBoard(g2);
        
        for(Observer ob : observers){
            ob.update(null, g);
        }
    }    

}

