package View;

import Controller.ChessController;
import Model.Chess;
import Pieces.Pieces;
import java.awt.BasicStroke;
import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.Observable;
import java.util.Observer;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class BoardFrame extends JFrame implements Observer{
    
    private Board board;
    private JPanel Canvas;
    private ChessController controller;
    private JLabel label =new JLabel();
    private String player;
    private JMenuBar menuBar;
    private static BufferedImage iconImg = null;
    private JFrame infoPanel;
    private JPanel log;
    private JTextArea logTex;
    private int posY;
    private JPanel timerA;
    private JTextArea timerAarea;
    private JPanel timerW;
    private JTextArea timerWarea;
    private JPanel timerB;
    private JTextArea timerBarea;
    
    public BoardFrame(Board board){      
        initComponents(board);
    }
    
    public void initMenu(){
        menuBar = new menuBar(controller);
        this.setJMenuBar(menuBar);
        
    }
    public void registerBoardObserver(Chess object){
        board.deleteObserver();
        board.registerObserver(object);
    }
    
    public void initComponents(Board board){
        this.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        
        c.gridx = 0;
        c.insets = new Insets(0,0,0,0);
        c.gridy = 0;
        c.anchor = GridBagConstraints.LINE_START;
        
        
        initFrame();
        initBoard(board);
        initLog();
        timerA("");
        timerW("");
        timerB("");
        
        JPanel data = new JPanel();
        this.add(this.board, c);
        
        data.add(label);
        posY = 0;
        log.setLayout(new GridBagLayout());
        log.setBackground(Color.WHITE);
        c.gridx = 1;
        c.insets = new Insets(0,10,0,0);
        this.add(log, c);
        c.gridx = 0;
        c.gridy = 1;
        c.insets = new Insets(0,130,0,0);
        
        this.add(data, c);
        
       
      
        timerA.setBorder(BorderFactory.createLineBorder(Color.black, 2));
        timerW.setBorder(BorderFactory.createLineBorder(Color.red, 2));
        timerB.setBorder(BorderFactory.createLineBorder(Color.black, 2));
         timerB.setBackground(Color.white);
          timerA.setBackground(Color.white);
           timerW.setBackground(Color.white);
        JPanel clocks = new JPanel();
        clocks.setLayout(new GridBagLayout());
        c.insets = new Insets(130,0,0,0);
        c.gridx = 0;
        c.gridy = 2;
        clocks.add(timerW, c);
        c.insets = new Insets(10,0,0,0);
        c.gridx = 0;
        c.gridy = 1;
         
        
       
        clocks.add(timerA, c);
     c.insets = new Insets(10,0,130,0);
        c.gridx = 0;
        c.gridy = 0;
        clocks.add(timerB, c);
        c.insets = new Insets(0,30,0,0);
        c.gridx = 2;
        c.gridy = 0;
        this.add(clocks, c);
        setLocationByPlatform(true);
        this.pack();
        
        this.setLocationRelativeTo(null);
       
        
    }
    
    
    public void setColorW(Color c){
        timerW.setBorder(BorderFactory.createLineBorder(c, 2));
    }
    
    public void setColorB(Color c){
        timerB.setBorder(BorderFactory.createLineBorder(c, 2));
    }
    
    public void timerA(String s){
        timerA = new JPanel();
        timerAarea = new JTextArea();
        timerAarea.setEditable(false);
       
        timerA.add(timerAarea);
    }
    
    public void attTimerA(String s){
        timerAarea.setText(s);
    }
    
    
    public void timerB(String s){
        timerB = new JPanel();
        timerBarea = new JTextArea();
        timerBarea.setEditable(false);
       
        timerB.add(timerBarea);
    }
    
    public void attTimerB(String s){
        timerBarea.setText(s);
    }
     
    
     public void timerW(String s){
        timerW = new JPanel();
        timerWarea = new JTextArea();
        timerWarea.setEditable(false);
        timerW.add(timerWarea);
    }
    
    public void attTimerW(String s){
        timerWarea.setText(s);
    }
    public void setNewLog(String s){
        JLabel newLog= new JLabel(s);
        
        GridBagConstraints c = new GridBagConstraints();
        
        c.gridx = 0;
        c.insets = new Insets(0,0,0,0);
        c.gridy = posY;
        c.anchor = GridBagConstraints.LINE_START;
        
        log.add(newLog, c);
        posY++;
    }
    
    public void addNewLog(String s){
        logTex.append(s+"\n");
        return;
    }
    
    public void resetLog(){
        logTex.setText(null);
    }
    
    public int checkForLoad(){
           JOptionPane load = new JOptionPane();
           InputStream is = this.getClass().getResourceAsStream("img/piecesicon2.png");
        if(iconImg == null){
            try {
               iconImg = ImageIO.read(is);
            } catch (IOException ex) {
           
            }
           
        }
        ImageIcon icon = new ImageIcon(BoardFrame.class.getResource("img/piecesicon4.png"));
        return load.showConfirmDialog(null, "Do you want to load your previous save?", "Load", JOptionPane.YES_NO_OPTION,JOptionPane.INFORMATION_MESSAGE, icon);
        
    
    }
    
    public void setPlayerLabel(Pieces.Color color, Boolean check, Boolean checkMate){
        
        if(color == Pieces.Color.BLACK){
            if(checkMate)
                player = "Black Checkmate";
            else if (check){
            player="Black Check";
            }
            else
                player="Black";
        }
        else{
            if(checkMate)
                player = "White Checkmate";
            else if (check){
                player="White Check";
            }
            else
                player="White";
        
        } 
            
        String playerTurn = String.format("%10s ", player);

        label.setText(playerTurn);
        label.setFont(new Font("Arial", Font.PLAIN, 24));
    }
    
    /*Sets the Window*/
    private void initFrame(){
        this.setVisible(false);
        this.setPreferredSize(new Dimension(800, 600));
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setTitle("XadrezUltimate");
        InputStream is = this.getClass().getResourceAsStream("img/icon.png");
        if(iconImg == null){
            try {
               iconImg = ImageIO.read(is);
            } catch (IOException ex) {
           
            }
           
        }
       
        this.setIconImage(iconImg);
    }
    
    private void initLog(){
        log = new JPanel();
        log.setPreferredSize(new Dimension(150,400));
        
        logTex = new JTextArea (5,10);
        logTex.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(logTex);
        scrollPane.setVerticalScrollBarPolicy(
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setPreferredSize(new Dimension(150, 400));
       
        logTex.setEditable(false);
        logTex.setFont(new Font("Arial", Font.PLAIN, 16));
        logTex.setLineWrap(true);
        logTex.setWrapStyleWord(true);
        GridBagConstraints cons = new GridBagConstraints();
        cons.weightx = 1.0;
        cons.weighty = 1.0;
        log.add(scrollPane, cons);
    }
    
    /*Sets the JPanel*/
    private void initBoard(Board board){
        FlowLayout experimentLayout = new FlowLayout(FlowLayout.CENTER);
        Canvas = new JPanel();
        this.board = board;    
        this.board.setPreferredSize(new Dimension(400, 400));
        this.board.setBackground(Color.lightGray);      
        this.board.setLayout(experimentLayout);    
    }
 
     public void addController(ChessController controller){
        this.controller = controller;
        this.board.addMouseListener(controller);
        this.board.addMouseMotionListener(controller);
        this.addKeyListener(controller);
    }
     
    @Override
    public void update(Observable o, Object arg) {
        controller.drawMouseTile((Graphics2D) arg);
        controller.drawHighlighted((Graphics2D) arg);
        controller.drawSelected((Graphics2D) arg);
        controller.drawPlayerLabel();
        
   }

    public void infoPanel(){
        if (infoPanel != null){
            infoPanel.setVisible(false); //you can't see me!
            infoPanel.dispose();
        }
        infoPanel = new JFrame();
        infoPanel.setIconImage(iconImg);
        infoPanel.setLocationRelativeTo(this);
        infoPanel.setLocation(this.getLocationOnScreen().x+250, this.getLocationOnScreen().y+100);
        infoPanel.setSize(new Dimension(300,300));
        infoPanel.setVisible(true);
        JPanel panel = new JPanel();
        panel.setBackground(Color.white);
     
        JLabel label = new JLabel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.anchor = GridBagConstraints.LINE_START;
        c.gridx = 0;
        c.insets = new Insets(20,10,0,20);
        c.gridy = 0;
        label.setText("This game was created by Marcelo B Diani");
        panel.add(label, c);
        
        label = new JLabel();
        label.setText("Thanks for playing");
        
        c.anchor = GridBagConstraints.LINE_END;
        c.insets = new Insets(40,0,0,20);
       
        c.gridx = 0;
        c.gridy = 1;
        panel.add(label, c);
        
         label = new JLabel();
        label.setText("Any bug please contact ");
        
        c.anchor = GridBagConstraints.LINE_START;
        c.insets = new Insets(40,10,0,20);
       
        c.gridx = 0;
        c.gridy = 2;
        panel.add(label, c);
        
         label = new JLabel();
        label.setText("marcelodianib@gmail.com");
        
        c.anchor = GridBagConstraints.LINE_END;
        c.insets = new Insets(10,0,0,20);
       
        c.gridx = 0;
        c.gridy = 3;
        panel.add(label, c);
        
        label = new JLabel();
        c.gridx = 0;
        c.gridy = 4;
        c.ipady = 30;
        label.setText("September 06, 2016");
        c.insets = new Insets(10,0,0,20);
         panel.add(label, c);
         infoPanel.setResizable(false);
        infoPanel.add(panel);
        infoPanel.setAlwaysOnTop(true);
        infoPanel.repaint();
        infoPanel.pack();
       
       
    }
    
    public Object getBoardPanel() {
        return this.board;
    }
 }

