
package View;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;
import Controller.ChessController;
import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.UIManager;
 
public class menuBar extends JMenuBar {
 protected static BufferedImage iconImgBlack = null;
 protected static BufferedImage iconImgWhite = null;
//Build the first menu.
    public menuBar(ChessController controller){
    UIManager.getDefaults().put("Button.showMnemonics", Boolean.TRUE);
    JMenu menu = new JMenu("File");
    menu.addActionListener(controller);
    menu.setMnemonic(KeyEvent.VK_F);
    menu.getAccessibleContext().setAccessibleDescription(
        "Menu");
    menu.setDisplayedMnemonicIndex(0);
    this.add(menu);

JMenu submenu = new JMenu("New game");
submenu.setMnemonic(KeyEvent.VK_N);

InputStream is = this.getClass().getResourceAsStream("img/whitepawn.png");
        if(iconImgWhite == null){
            try {
                iconImgWhite = ImageIO.read(is);
            } catch (IOException ex) {
            }
            
        }
JMenuItem menuItem = new JMenuItem("White" , new ImageIcon(iconImgWhite));        
menuItem.setAccelerator(KeyStroke.getKeyStroke(
        KeyEvent.VK_1, ActionEvent.ALT_MASK));
submenu.add(menuItem);

menuItem.addActionListener(controller);
InputStream iss = this.getClass().getResourceAsStream("img/blackpawn.png");
        if(iconImgBlack == null){
            try {
                iconImgBlack = ImageIO.read(iss);
            } catch (IOException ex) {
            }
            
        }
        
menuItem = new JMenuItem("Black" , new ImageIcon(iconImgBlack));
menuItem.setAccelerator(KeyStroke.getKeyStroke(
        KeyEvent.VK_2, ActionEvent.ALT_MASK));
menuItem.addActionListener(controller);
submenu.add(menuItem);
menu.add(submenu);
menu.addSeparator();
menuItem = new JMenuItem("Save game", KeyEvent.VK_S);
menuItem.addActionListener(controller);   
menuItem.setDisplayedMnemonicIndex(0);

menuItem.setAccelerator(KeyStroke.getKeyStroke(
        KeyEvent.VK_S, ActionEvent.CTRL_MASK));
menuItem.getAccessibleContext().setAccessibleDescription(
        "Save the game");
menu.add(menuItem);

menuItem = new JMenuItem("Load game", KeyEvent.VK_L);
menuItem.addActionListener(controller);   
menuItem.setDisplayedMnemonicIndex(0);

menuItem.setAccelerator(KeyStroke.getKeyStroke(
        KeyEvent.VK_L, ActionEvent.CTRL_MASK));
menuItem.getAccessibleContext().setAccessibleDescription(
        "Load the game");
menu.add(menuItem);

menu.addSeparator();
//a group of JMenuItems
menuItem = new JMenuItem("Leave",
                         KeyEvent.VK_L);
menuItem.addActionListener(controller);   
menuItem.setDisplayedMnemonicIndex(0);

menuItem.setAccelerator(KeyStroke.getKeyStroke(
        KeyEvent.VK_W, ActionEvent.CTRL_MASK));
menuItem.getAccessibleContext().setAccessibleDescription(
        "Leave the game");
menu.add(menuItem);


menu = new JMenu("Config");
menu.addActionListener(controller);
    menu.setMnemonic(KeyEvent.VK_C);
    menu.getAccessibleContext().setAccessibleDescription(
        "Configurations");
    menu.setDisplayedMnemonicIndex(0);
    this.add(menu);

    submenu = new JMenu("Auto save");
    submenu.setMnemonic(KeyEvent.VK_A);

ButtonGroup group = new ButtonGroup();
JRadioButtonMenuItem autosave = new JRadioButtonMenuItem("On");
autosave.setSelected(true);
autosave.setMnemonic(KeyEvent.VK_N);
autosave.addActionListener(controller);
group.add(autosave);
submenu.add(autosave);
autosave = new JRadioButtonMenuItem("Off");
autosave.addActionListener(controller);
autosave.setMnemonic(KeyEvent.VK_O);
group.add(autosave);
submenu.add(autosave);    
menu.add(submenu);

submenu = new JMenu("Save time");
    submenu.setMnemonic(KeyEvent.VK_V);

group = new ButtonGroup();
autosave = new JRadioButtonMenuItem("15s");

autosave.addActionListener(controller);
group.add(autosave);
submenu.add(autosave);
autosave = new JRadioButtonMenuItem("30s");
autosave.setSelected(true);
autosave.addActionListener(controller);
group.add(autosave);
submenu.add(autosave); 

autosave = new JRadioButtonMenuItem("60s");
autosave.addActionListener(controller);
group.add(autosave);
submenu.add(autosave);
autosave = new JRadioButtonMenuItem("120s");
autosave.addActionListener(controller);
group.add(autosave);
submenu.add(autosave);
//submenu.add(autosave);
autosave = new JRadioButtonMenuItem("Set another");
autosave.addActionListener(controller);
group.add(autosave);
submenu.add(autosave);

menu.add(submenu);

menu.addSeparator();
submenu = new JMenu("Type of game");
    submenu.setMnemonic(KeyEvent.VK_T);

group = new ButtonGroup();
autosave = new JRadioButtonMenuItem("1 min");

autosave.addActionListener(controller);
group.add(autosave);
submenu.add(autosave);

autosave = new JRadioButtonMenuItem("5 min");

autosave.addActionListener(controller);
group.add(autosave);
submenu.add(autosave);


autosave = new JRadioButtonMenuItem("10 min");

autosave.addActionListener(controller);
group.add(autosave);
submenu.add(autosave);


autosave = new JRadioButtonMenuItem("15 min");

autosave.addActionListener(controller);
group.add(autosave);
submenu.add(autosave);


autosave = new JRadioButtonMenuItem("30 min");
autosave.setSelected(true);
autosave.addActionListener(controller);

group.add(autosave);
submenu.add(autosave);


autosave = new JRadioButtonMenuItem("60 min");

autosave.addActionListener(controller);
group.add(autosave);
submenu.add(autosave);

autosave = new JRadioButtonMenuItem("120 min");

autosave.addActionListener(controller);
group.add(autosave);
submenu.add(autosave);

menu.add(submenu);


//Build second menu in the menu bar.
menu = new JMenu("Info");
menu.setMnemonic(KeyEvent.VK_I);
menu.setDisplayedMnemonicIndex(0);
menu.getAccessibleContext().setAccessibleDescription(
        "Informations about the game");

menu.addMouseListener(new MouseListener() {
        @Override
        public void mouseClicked(MouseEvent e) {
        }

        @Override
        public void mousePressed(MouseEvent e) {
            controller.infoPanelAction();
        }

        @Override
        public void mouseReleased(MouseEvent e) {
        }

        @Override
        public void mouseEntered(MouseEvent e) {
        }

        @Override
        public void mouseExited(MouseEvent e) {
        }
    });
       


this.add(menu);

}
}