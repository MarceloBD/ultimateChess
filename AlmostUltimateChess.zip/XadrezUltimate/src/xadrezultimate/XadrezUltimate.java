/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package xadrezultimate;

import Model.Chess;
import Controller.ChessController;
import View.Board;
import View.BoardFrame;

public class XadrezUltimate {
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
               
                Board board = new Board();                                      //Creates a JPanel for board
                BoardFrame view = new BoardFrame(board);                        //Creates the JFrame of the main window and add board
                Chess model = new Chess();                                      //Organize the events of the game
                board.registerObserver(view);                                   //Sets Observer
                board.registerObserver(model);
                ChessController controller = new ChessController();             //Sets Controller
                controller.addView(view);
                controller.addModel(model);                                     //Add controller to frame
                view.addController(controller);
                view.initMenu();
                
                controller.startMainWindow();                                   //Sets window visible
            }
        });
    }
}
